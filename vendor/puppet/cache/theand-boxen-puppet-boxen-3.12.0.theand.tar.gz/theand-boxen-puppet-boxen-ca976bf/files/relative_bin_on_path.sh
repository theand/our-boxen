# Add ./bin to the path. This happens after initialization to make
# sure local stubs take precedence over stuff like rbenv.

#export PATH=bin:$PATH
