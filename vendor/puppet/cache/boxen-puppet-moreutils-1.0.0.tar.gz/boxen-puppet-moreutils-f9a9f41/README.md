[![Build
Status](https://travis-ci.org/boxen/puppet-moreutils.png?branch=master)](https://travis-ci.org/boxen/puppet-moreutils)

# Moreutils

## Usage

```puppet
include moreutils
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
