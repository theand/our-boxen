# AppCleaner Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-appcleaner.png?branch=master)](https://travis-ci.org/boxen/puppet-appcleaner)

[AppCleaner](http://www.freemacsoft.net/appcleaner/) is a small application which allows you to thoroughly uninstall unwanted apps.

## Usage

`include appcleaner`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
