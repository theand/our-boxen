# Adobe Brackets Puppet Module for Boxen [![Build Status](https://travis-ci.org/carlyeks/puppet-brackets.png?branch=master)](https://travis-ci.org/carlyeks/puppet-brackets)

Install [Adobe Brackets](http://www.brackets.io/), an HTML5 IDE built using HTML5.

## Usage

```puppet
include brackets
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
