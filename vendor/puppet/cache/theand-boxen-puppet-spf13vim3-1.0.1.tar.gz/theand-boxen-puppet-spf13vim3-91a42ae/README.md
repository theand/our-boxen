# spf13vim3 Puppet Module for Boxen

Installs [spf13-vim](http://vim.spf13.com/) via Boxen

Requires the following boxen modules:

* [boxen](https://github.com/boxen/puppet-boxen)

## Usage

```puppet
include spf13vim3
```

## Developing

Write code.

Run `script/cibuild`.
