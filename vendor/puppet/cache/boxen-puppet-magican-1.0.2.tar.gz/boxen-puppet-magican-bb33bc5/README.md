# Magican Puppet Module for Boxen [![Build Status](https://travis-ci.org/boxen/puppet-magican.png?branch=master)](https://travis-ci.org/boxen/puppet-magican)

Install [Magican](), Mac cleaner, monitor & duplicate remover and more...

## Usage

```puppet
include magican
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
