[![Build Status](https://api.travis-ci.org/boxen/puppet-phpstorm.png?branch=master)](https://travis-ci.org/boxen/puppet-phpstorm)
# PHPStorm Puppet Module for Boxen 

A PHPStorm module for Boxen, you guys!!! 

## Usage

```puppet
include phpstorm
```

## Required Puppet Modules

* `boxen`
