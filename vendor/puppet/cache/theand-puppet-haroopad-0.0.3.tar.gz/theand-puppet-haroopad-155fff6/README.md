# Haroopad Puppet Module for Boxen

Install [Haroopad](http://pad.haroopress.com/).

## Usage

```puppet
include haroopad
```

## Required Puppet Modules

* `boxen`