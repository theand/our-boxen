# P4Merge Module for Boxen

Install [p4merge](http://www.perforce.com/product/components/perforce-visual-merge-and-diff-tools), application for Visual Merge and Diff Tools.

## Usage

```puppet
include p4merge
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
