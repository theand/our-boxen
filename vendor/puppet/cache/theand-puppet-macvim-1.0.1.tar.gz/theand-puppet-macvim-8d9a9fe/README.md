# MacVim Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-macvim.png?branch=master)](https://travis-ci.org/boxen/puppet-macvim)

## Usage

```puppet
include macvim
```

## Required Puppet Modules

* boxen
* homebrew
* stdlib

Also requires a full Xcode install.

