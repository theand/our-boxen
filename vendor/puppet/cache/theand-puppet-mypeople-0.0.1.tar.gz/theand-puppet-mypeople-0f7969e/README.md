# MyPeople Puppet Module for Boxen

Install [MyPeople](https://mypeople.daum.net/mypeople/web/main.do).

## Usage

```puppet
include mypeople
```

## Required Puppet Modules

* `boxen`