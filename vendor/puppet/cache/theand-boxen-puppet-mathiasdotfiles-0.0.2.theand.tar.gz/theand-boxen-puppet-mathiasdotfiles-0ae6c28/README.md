# Mathias's dotfiles Puppet Module for Boxen

Install [Mathias's dotfiles](https://github.com/mathiasbynens/dotfiles).

## Usage

```puppet
include mathiasdotfiles
```

## Required Puppet Modules

* `boxen`