# DaumCloud Puppet Module for Boxen

Install [DaumCloud](http://cloud.daum.net/disk/Index.daum#ViewPcAppHelpCmd).

## Usage

```puppet
include daumcloud
```

## Required Puppet Modules

* `boxen`