# MySql Workbench Puppet Module for Boxen

Install [MySql Workbench](http://www.mysql.com/products/workbench/), an Open Source visual database design tool for [MySql](http://www.mysql.com/).

## Usage

```puppet
include mysql_workbench
```

## Required Puppet Modules

* `boxen`