# MR

[![Build Status](https://travis-ci.org/boxen/puppet-mr.png)](https://travis-ci.org/boxen/puppet-mr)

MR is a tool to manage Multiple Repositories at the same time.
More details at http://joeyh.name/code/mr/

## Usage

```puppet
include mr
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
