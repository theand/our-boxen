2014-03-30- Ryan Skoblenick <ryan@skoblenick.com> - 0.2.0
  * Updated default version of Filezilla to 3.8.0

2013-09-22- Ryan Skoblenick <ryan@skoblenick.com> - 0.1.0
  * Initial version
